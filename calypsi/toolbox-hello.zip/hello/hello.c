#include "../lib/include/toolbox.h"

#include <stdio.h>

int main(int c, char * argv[]) {
	printf("Hello, Foenix Toolbox!\n");

	while (1) ;
}